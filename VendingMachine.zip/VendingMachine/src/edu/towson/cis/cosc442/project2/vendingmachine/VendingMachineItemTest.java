package edu.towson.cis.cosc442.project2.vendingmachine;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class VendingMachineItemTest {
	VendingMachineItem item; 

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		item = new VendingMachineItem("Candy", 4.00);
	}

	@After
	public void tearDown() throws Exception {
		item = null;
	}

	@Test
	public void testVendingMachineItem() {
		
	}

	@Test
	public void testGetName() {
		assertEquals("Candy", item.getName());
	}

	@Test
	public void testGetPrice() {
		assertEquals(4.00, item.getPrice(), 0.001);
	}

}
